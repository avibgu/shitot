/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package HelpFunctions;

/**
 *
 * @author shiran
 */
public class Pair {

    private double a,b;

    public Pair(double x,double y){
        a=x;
        b=y;
    }

    public double getA(){
        return a;
    }

    public double getB(){
        return b;
    }
}
